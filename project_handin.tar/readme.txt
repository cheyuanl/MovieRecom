a. Names and Andrew ID:
Malvin De Nunez Estevez - mdenunez
Che-Yuan Liang - cheyuanl
Anmol Jain - anmolj

b. How to run the code
1. Download “data” file from the link provided in d . Make sure it is saved as “data” folder.
2. Store the data file in the same folder as the MovieRecom_FinalReport.ipynb 
3. You might need to install the following package:
   pyFM using- pip install git+https://github.com/coreylynch/pyFM
4. Open the MovieRecom_FinalReport.ipynb and run it cell by cell

c. NBViewer link 
https://nbviewer.jupyter.org/github/cheyuanl/MovieRecom/blob/master/final/MovieRecom_FinalReport.ipynb

d. Link to data file
https://drive.google.com/open?id=0B8lfchtrKaRLMlBWMmJzd0gzR2c (You can download it only by using andrew.cmu.edu id)


e. References

1. http://www.csie.ntu.edu.tw/~b97053/paper/Rendle2010FM.pdf

2. https://www.ismll.uni-hildesheim.de/pub/pdfs/Rendle_et_al2011-Context_Aware.pdf

3. F. Maxwell Harper and Joseph A. Konstan. 2015. The MovieLens Datasets: History and Context. ACM Transactions on Interactive Intelligent Systems (TiiS) 5, 4, Article 19 (December 2015), 19 pages. DOI=http://dx.doi.org/10.1145/2827872

4. http://www.kemaswill.com/uncategorized/from-matrix-factorization-to-factorization-machines/

5. https://devhub.io/repos/pprett-pyFM


